'use strict';

const functions = require('firebase-functions');
const { WebhookClient } = require('dialogflow-fulfillment');
const { google } = require('googleapis');

// Enter your calendar ID below and service account JSON below
const calendarId = 'c_rv23rh3kp06cr1lqovtibbp490@group.calendar.google.com';
const serviceAccount = {
  type: 'service_account',
  project_id: 'birthdaycakedeliverysched-jhig',
  private_key_id: 'a2833917ab7ca48d0f9d4b33de84af31ca611a7b',
  private_key:
    '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCzvqUN4XLQjLxY\n4uDjwouCHxkUC/LCndyBtaUyuQjvSzhoVLwulW81Eja/LNhHkoFuDVIhyHmtQLpf\nEXbA45+MwL98prwG/P8XfjgkfYqtGlI7bV2k/5SW+uhraZJsT9PNdbuQFw0Tlha+\nEa/R6t6sPQU2GbDOpgZpgwwHcmg8Zf6LCaI8iD8BwRmd8ijZsfcCUx7pNwaSIOT0\nNB+oXIUkNwZUtHtacTjDc4Rfjd26d7Mr4xR0LLrywQZB67AYPZJd56nyRVO9b0yZ\nZE/dMkz2efHl7y6J5q2x8H9M0WciHogETf7z6d8KIUTIncKJ+eyYDvfVZFETifNU\nxogsqgTHAgMBAAECggEAOUnSIZJxnba9cTcepnkjLd3riFAml5Do7w6OEJSZHGvF\nFrurHs3SHAAqItSQOn+fcQwd2VakMWwn+pT+XIwwFhR486nQ1Ale5IX+LuM0h+eT\nvg0lg6lSGqzt1w5W9N6ciyezGEHAkTWNGhdZCnbpccwhFRUrHTIdaROzicwVHOp8\naJwhsgOsSsJ0cOE6aYF2lYHiFdDesQXeyn4zc8MM84rRqxdoTU8pnBJfuBu/4sah\n1ZB7kSww7WVGtFq8pnyThLmdPYaScVCcuzPnyK1eFttlf6ffgQk98EuSRbXB7+I1\nAEtJIg8NRbIet0LyvNWEUvYsqYgjUgqscwP/ra2EQQKBgQDbVGt9UtGMzNMGYIaN\n02B8iO8xqn6aPvJIsXoGBlkeZXahthG2R6YiUxXFLf+ihyVJ0A7FDqdNedZP/bif\ntyiZWpZU93KUyrDTx3C4K7kfaXb4SjXJeuqVz0XbtYAgQeVwjGJNzKBByX3/PcCc\nwPOsR3m1f9rK964ukv8mZXchLQKBgQDRy++w2S0PLJyClIOvSW7LFMnme8RtenFh\n6xwsCqXCCzsVbGw22Qzj570AdleFcJ6JkIzR+XoHScdEUO2JWpiG3uEkdQpv023/\n4bqwWEkmcI9TFmmxbQCds0qerEyTL2Tb00v01pfEBVOzoclRUhcy+XynbIT0SWBx\nvVx6XgduQwKBgQCsWJfmcK+tPj4MYskYpSLKeSfMFTdKqW/lY2CJX2+kDQK9a75b\nR83qZvNScCTSZ/QLHmycuDkLDlQzoyHyjxBeAOrkdVUaSnPM1olijyj23/7WeCnv\n2qB/e9JfJS47KszKNeYBUGwVhel2KeYyxwQzOi8PShp5J0s92dCZMV39OQKBgQC2\ne+owbKdp9Ibqeh4U4Q3S7XE03uEbzQ5EesnVcSl/IF+zIcz65E73CgJ3HXjBZBUy\nWR50IclH/5+pR69l8vyLC+DP4lJCtKiQkxrc+t4d5nh0cCFdKBAKHALDA+HTgLz9\nDMyb2fDGm0+UBxzidEIjn6kSxCzdg9m09V40Pge+mwKBgFOVN4s+BHXw/WbMKg2O\nGBHpvicJjFrav5oN0BogciakULEdaRs36cKTsqauPTaVdqlL5LSO3UdPV4dcbFvZ\nce6L3oCX7+T0LvFtLbYSgDnETj7qUZVGITr7DAuFa5AjM/GEypCuDzoNP6gxRwoz\nEAZ4NNXsTaWk0V19w5ikHiph\n-----END PRIVATE KEY-----\n',
  client_email:
    'birthdaycakedeliveryscheduler@birthdaycakedeliverysched-jhig.iam.gserviceaccount.com',
  client_id: '118137996857095334998',
  auth_uri: 'https://accounts.google.com/o/oauth2/auth',
  token_uri: 'https://oauth2.googleapis.com/token',
  auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
  client_x509_cert_url:
    'https://www.googleapis.com/robot/v1/metadata/x509/birthdaycakedeliveryscheduler%40birthdaycakedeliverysched-jhig.iam.gserviceaccount.com',
};

// Set up Google Calendar Service account credentials
const serviceAccountAuth = new google.auth.JWT({
  email: serviceAccount.client_email,
  key: serviceAccount.private_key,
  scopes: 'https://www.googleapis.com/auth/calendar',
});

const calendar = google.calendar('v3');
process.env.DEBUG = 'dialogflow:*'; // enables lib debugging statements

const timeZone = 'America/Los_Angeles';
const timeZoneOffset = '-07:00';

exports.dialogflowFirebaseFulfillment = functions.https.onRequest(
  (request, response) => {
    const agent = new WebhookClient({ request, response });

    function newOrderIntentHandlder(agent) {
      const order = agent.getContext('order').parameters;
      console.log('parameters', order);
      agent.setContext({ name: 'order', lifespan: '0' });
      // Calculate calender start and end datetimes (end = +1hr from start)
      const dateTimeStart = new Date(
        Date.parse(
          order.date.split('T')[0] +
            'T' +
            order.time.split('T')[1].split('-')[0] +
            timeZoneOffset
        )
      );
      console.log('dateTimeStart', dateTimeStart);

      const dateTimeEnd = new Date(
        new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1)
      );

      const deliveryTimeString = dateTimeStart.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        timeZone: timeZone,
      });
      const cake_type = order.TypeOfCake;
      // Check the availability of the time, and make an appointment if there is time on the calendar
      return createCalendarEvent(dateTimeStart, dateTimeEnd, cake_type)
        .then(() => {
          agent.add(
            `Delivery Scheduled - ${cake_type} cake ${deliveryTimeString}.`
          );
        })
        .catch(() => {
          agent.add(
            `I'm sorry, there is already an order present in your calender for ${deliveryTimeString}. 
             Check the orders of ${deliveryTimeString.split(',')[0]}.`
          );
        });
    }

    //Creates calendar event in Google Calendar
    function createCalendarEvent(dateTimeStart, dateTimeEnd, cake_type) {
      return new Promise((resolve, reject) => {
        calendar.events.list(
          {
            auth: serviceAccountAuth, // List events for time period
            calendarId: calendarId,
            timeMin: dateTimeStart.toISOString(),
            timeMax: dateTimeEnd.toISOString(),
          },
          (err, calendarResponse) => {
            // Check if there is a event already on the Calendar
            if (err || calendarResponse.data.items.length > 0) {
              reject(
                err ||
                  new Error(
                    'Requested time conflicts with another order delivery'
                  )
              );
            } else {
              // Create event for the requested time period
              calendar.events.insert(
                {
                  auth: serviceAccountAuth,
                  calendarId: calendarId,
                  resource: {
                    summary: cake_type + ' cake',
                    description: cake_type + ' cake',
                    start: { dateTime: dateTimeStart },
                    end: { dateTime: dateTimeEnd },
                  },
                },
                (err, event) => {
                  err ? reject(err) : resolve(event);
                }
              );
            }
          }
        );
      });
    }

    function getOrdersIntentHandlder(agent) {
      const dateTimeStart = new Date(
        Date.parse(
          agent.parameters.date.split('T')[0] +
            'T' +
            '00:00:00' +
            timeZoneOffset
        )
      );
      console.log('dateTimeStart', dateTimeStart);
      const dateTimeEnd = new Date(
        new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 24)
      );
      console.log('dateTimeEnd', dateTimeEnd);

      return listCalendarEvent(dateTimeStart, dateTimeEnd)
        .then((events) => {
          const length = events.length;
          let appointmentDay = dateTimeStart.toLocaleDateString('en-US', {
            month: 'long',
            day: 'numeric',
            timeZone: timeZone,
          });
          const day = appointmentDay.split(',')[0];
          if (length == 0) {
            return agent.add(
              `You don't have any orders to be delivered on ${day}`
            );
          } else {
            let word = length == 1 ? 'order' : 'orders';
            let speakOut = `You have ${length} ${word} to be delivered on ${day} : `;
            for (var i = 0; i < length; i++) {
              var event = events[i];
              var start = event.start.dateTime || event.start.date;
              let startDate = new Date(start);
              if (i != 0) {
                if (i < length - 1) {
                  speakOut += `, `;
                } else {
                  speakOut += ` and `;
                }
              }
              let appointmentTimeString = startDate.toLocaleString('en-US', {
                month: 'long',
                day: 'numeric',
                hour: 'numeric',
                timeZone: timeZone,
              });
              const time = appointmentTimeString.split(',')[1];
              speakOut += `${event.summary} at ${time}`;
            }
            return agent.add(speakOut);
          }
        })
        .catch((error) => {
          agent.add(error);
        });
    }

    function listCalendarEvent(dateTimeStart, dateTimeEnd) {
      return new Promise((resolve, reject) => {
        calendar.events.list(
          {
            auth: serviceAccountAuth, // List events for time period
            calendarId: calendarId,
            timeMin: dateTimeStart.toISOString(),
            timeMax: dateTimeEnd.toISOString(),
          },
          (err, calendarResponse) => {
            if (err) {
              //reject(err);
              reject(
                new Error('Some Issue in fetching data from your Calender')
              );
            } else {
              resolve(calendarResponse.data.items);
            }
          }
        );
      });
    }

    function deleteOrderIntentHandlder(agent) {
      // Calculate appointment start and end datetimes (end = +1hr from start)
      const order = agent.getContext('delete').parameters;
      agent.setContext({ name: 'delete', lifespan: '0' });
      const dateTimeStart = new Date(
        Date.parse(
          order.date.split('T')[0] +
            'T' +
            order.time.split('T')[1].split('-')[0] +
            timeZoneOffset
        )
      );
      console.log('dateTimeStart', dateTimeStart);
      const dateTimeEnd = new Date(
        new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1)
      );
      const appointmentTimeString = dateTimeStart.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        timeZone: timeZone,
      });
      // Check the availability of the time, and make an appointment if there is time on the calendar
      return deleteCalendarEvent(dateTimeStart, dateTimeEnd)
        .then((summary) => {
          agent.add(
            `Ok, removed the ${summary} order which was scheduled on ${appointmentTimeString}`
          );
        })
        .catch(() => {
          agent.add(
            `No order is scheduled on ${appointmentTimeString} to remove.`
          );
        });
    }

    //deleteCalendarEvent in Google Calendar
    function deleteCalendarEvent(dateTimeStart, dateTimeEnd) {
      return new Promise((resolve, reject) => {
        calendar.events.list(
          {
            auth: serviceAccountAuth, // List events for time period
            calendarId: calendarId,
            timeMin: dateTimeStart.toISOString(),
            timeMax: dateTimeEnd.toISOString(),
          },
          (err, calendarResponse) => {
            // Check if there is a event already on the Calendar
            if (err || calendarResponse.data.items.length == 0) {
              reject(
                new Error('No order was scheduled to remove at the given time')
              );
            } else {
              // delete event for the requested time period
              let event = calendarResponse.data.items[0];
              const summary = event.summary;
              const eventId = event.id;
              calendar.events.delete(
                {
                  auth: serviceAccountAuth,
                  calendarId: calendarId,
                  eventId: eventId,
                },
                (err, event) => {
                  err ? reject(err) : resolve(summary);
                }
              );
            }
          }
        );
      });
    }

    function updateCakeTypeIntentHandlder(agent) {
      const cake_type = agent.parameters.TypeOfcake;

      // Calculate appointment start and end datetimes (end = +1hr from start)
      const dateTimeStart = new Date(
        Date.parse(
          agent.parameters.date.split('T')[0] +
            'T' +
            agent.parameters.time.split('T')[1].split('-')[0] +
            timeZoneOffset
        )
      );
      console.log('dateTimeStart', dateTimeStart);
      const dateTimeEnd = new Date(
        new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1)
      );
      const deliveryTimeString = dateTimeStart.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        timeZone: timeZone,
      });
      // Check the availability of the time, and update an appointment if there is time on the calendar
      return updateCalendarEvent(dateTimeStart, dateTimeEnd, cake_type)
        .then(() => {
          agent.add(`Order Updated - ${cake_type} cake ${deliveryTimeString}.`);
        })
        .catch((error) => {
          agent.add(`No Order to update on ${deliveryTimeString}.`);
        });
    }

    //Update calendar event in Google Calendar
    function updateCalendarEvent(dateTimeStart, dateTimeEnd, cake_type) {
      return new Promise((resolve, reject) => {
        calendar.events.list(
          {
            auth: serviceAccountAuth, // List events for time period
            calendarId: calendarId,
            timeMin: dateTimeStart.toISOString(),
            timeMax: dateTimeEnd.toISOString(),
          },
          (err, calendarResponse) => {
            // Check if there is a event already on the Calendar
            if (err || calendarResponse.data.items.length == 0) {
              reject(new Error('No order to update at the given time'));
            } else {
              // delete event for the requested time period
              let event = calendarResponse.data.items[0];
              event.summary = cake_type + ' cake';
              const eventId = event.id;
              calendar.events.patch(
                {
                  auth: serviceAccountAuth,
                  calendarId: calendarId,
                  eventId: eventId,
                  resource: event,
                },
                (err, event) => {
                  err ? reject(err) : resolve(event);
                }
              );
            }
          }
        );
      });
    }

    let intentMap = new Map();
    intentMap.set('Confirmed Order Intent', newOrderIntentHandlder);
    intentMap.set('Confirm Order After Edit Intent', newOrderIntentHandlder);
    intentMap.set('Get Orders Intent', getOrdersIntentHandlder);
    intentMap.set('Confirm Delete Order Intent', deleteOrderIntentHandlder);
    intentMap.set('Update Cake Type Intent', updateCakeTypeIntentHandlder);
    agent.handleRequest(intentMap);
  }
);
